package termproject;

import java.util.Random;

public abstract class Skill{
	private static int tag;
	private String name;
	public String symbol;
	public int hitRate;
	protected abstract String getName();
	protected abstract int getTag();
	protected abstract String getSymbol();
	protected abstract int getHitRate();
}

class AttackSkill extends Skill{
	private int tag = 0;
	private String name;
	public int damage;
	public String type;
	public String symbol;
	public boolean isAD;
	AttackSkill(String name, int damage, String type, String symbol, boolean isAD, int hitRate){
		this.name = name;
		this.damage = damage;
		this.type = type;
		this.symbol = symbol;
		this.isAD = isAD;
		this.hitRate = hitRate;
	}
	public int getDamage() {
		return damage;
	}
	public String getType() {
		return type;
	}
	public String additive(Pokemon p) {
		Random random = new Random(System.currentTimeMillis());
		switch(this.name) {
		case "냉동빔":
			if(random.nextInt(10) < 3 && p.enemy.condition == 0) {
				p.enemy.condition = 6;
				return p.enemy.name + "의 토게피의 몸이 얼어붙었다!\n";
			}
			break;
		case "화염방사":
			if(random.nextInt(10) < 3 && p.enemy.condition == 0) {
				p.enemy.condition = 1;
				return p.enemy.name + "의 토게피는 화성을 입었다!\n";
			}
			break;
		case "오물폭탄":
			if(random.nextInt(10) < 3 && p.enemy.condition == 0) {
				p.enemy.condition = 2;
				return p.enemy.name + "의 토게피는 독에 걸렸다!\n";
			}
			break;
		case "100만볼트":
			if(random.nextInt(10) < 3 && p.enemy.condition == 0) {
				p.enemy.condition = 4;
				return p.enemy.name + "의 토게피는 마비 상태에 빠졌다!\n";
			}
			break;
		case "스톤엣지":
			if(random.nextInt(10) < 5) {
				p.enemy.SPcounter--;
				p.enemy.SP = (int)(p.enemy.SPcounter < 0 ? p.enemy.originSP/(1 + ((-1)*(float)p.enemy.SPcounter/2)) : p.enemy.originSP*(1 + (float)p.enemy.SPcounter/2));
				return p.enemy.name + "의 토게피의 스피드가 떨어졌다!\n";
			}
			break;
		}
		return "";
	}
	public int getTag() {
		return tag;
	}
	public String getName() {
		return name;
	}
	public String getSymbol() {
		return symbol;
	}
	public int getHitRate() {
		return hitRate;
	}
}

class ConditionalSkill extends Skill{
	private int tag = 1;
	private String name;
	public int condition;
	ConditionalSkill(String name, String symbol, int condition, int hitRate){
		this.name = name;
		this.symbol = symbol;
		this.condition = condition;
		this.hitRate = hitRate;
	}
	public void setCondition(Pokemon p) {
		p.condition = condition;
	}
	public int getTag() {
		return tag;
	}
	public String getName() {
		return name;
	}
	public String getSymbol() {
		return symbol;
	}
	public int getHitRate() {
		return hitRate;
	}
}

final class Barrier extends Skill{
	private int tag = 2;
	private String name = "방어";
	public int getTag() {
		return tag;
	}
	public String getName() {
		return name;
	}
	public String getSymbol() {
		return "(((( ooooogh,,, ))))";
	}
	public int getHitRate() {
		return 100;
	}
}


