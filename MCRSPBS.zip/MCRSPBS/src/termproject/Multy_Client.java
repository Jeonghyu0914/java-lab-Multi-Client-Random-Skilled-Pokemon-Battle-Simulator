package termproject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.InputStream;
import java.io.PrintStream;
import java.net.Socket;
import java.util.Scanner;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;

public class Multy_Client {

    public static void main(String[] args) throws IOException {
    	Multy_Client multiClient = new Multy_Client();
        multiClient.start();
    }

    public void start() throws IOException{
        Socket socket = null;
        BufferedReader in = null;
        Scanner scn = new Scanner(System.in);
             
        InputStream fis = new FileInputStream("userlist.txt");
        InputStreamReader isr = new InputStreamReader (fis);
        BufferedReader br = new BufferedReader(isr);
        String dataIn;
        String data;
        System.out.println("토게피의 이름을 입력해주세요!");
        data = scn.nextLine();
        dataIn = br.readLine(); 
        if(dataIn != null) {
	        while(dataIn.equals(data)){
	        	System.out.println("다른 이름을 입력해주세요.");
	        	data = scn.nextLine();
	        }
        }
        FileOutputStream fos = new FileOutputStream("userlist.txt");
    	OutputStreamWriter osw = new OutputStreamWriter(fos);	
        BufferedWriter bw = new BufferedWriter (osw);  
        if(dataIn != null) {
	        bw.write(dataIn);
	       	bw.newLine();
        }
        bw.write(data);
        bw.flush();
        br.close(); isr.close(); fis.close();
        bw.close(); osw.close(); fos.close();
       
        try {
            socket = new Socket("localhost", 8000);
            System.out.println("[서버와 연결되었습니다]");

            String name = data;
            Thread sendThread = new SendThread(socket, name);
            sendThread.start();

            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            boolean firstState = true;
            while (in != null) {
                String inputMsg = in.readLine();
                if(inputMsg != null && inputMsg.equals("이름: "+data+"의 토게피")) {
            		SendThread.stateString = inputMsg;
            		inputMsg = "응애";
                	for(int i = 0; i < 8; i++) {
                		SendThread.stateString += ("\n" + in.readLine());
                	}
                }
                if (("게임 종료.").equals(inputMsg)) {
                	System.out.println(inputMsg);
                	System.exit(0);
                }
                if(inputMsg.equals("응애") && firstState) {
                	System.out.println(SendThread.stateString);
                	firstState = false;
                }
                if(!(inputMsg.equals("응애"))) System.out.println(inputMsg);
                
                if(("상대방 입력 대기 중...").equals(inputMsg)) SendThread.inputPermission = false;
                else SendThread.inputPermission = true;
            }
        } catch (IOException e) {
            System.out.println("[서버 접속끊김]");
        } finally {
            try {
                if (socket != null) {
                    socket.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        System.out.println("[서버 연결종료]");
    }
}

class SendThread extends Thread {
    Socket socket = null;
    String name;
    public static boolean inputPermission = true;
    public static String stateString;
    Scanner scanner = new Scanner(System.in);

    public SendThread(Socket socket, String name) {
        this.socket = socket;
        this.name = name;
    }

    @Override
    public void run() {
        try {
            // 최초1회는 client의 name을 서버에 전송
            PrintStream out = new PrintStream(socket.getOutputStream());
            out.println(name);
            out.flush();

            while (true) {
            	if(inputPermission) {
	                String outputMsg = this.name+"/"+scanner.nextLine();
	                if(outputMsg.equals(this.name+"/3")) {
	                	System.out.println("----------------------------------------------------");
	                	System.out.println(stateString);
	                	System.out.println("----------------------------------------------------\r\n"
	                			+ name + "의 토게피는 무엇을 할까?\r\n"
	                			+ "1. 손가락 흔들기 2. 상처약 사용하기 3. 스텟 보기 4. 항복하기 >>");
	                	continue;
	                }
	                else {
	                	out.println(outputMsg);
		                out.flush();
	                }
	                if ("quit".equals(outputMsg)) break;
            	}
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}