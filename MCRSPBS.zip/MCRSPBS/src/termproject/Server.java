package termproject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.io.FileOutputStream;

public class Server {

    public static void main(String[] args) {
        Server server = new Server();
        server.start();
    }

    public void start() {
        ServerSocket serverSocket = null;
        Socket socket = null;
        try {
            serverSocket = new ServerSocket(8000);
            while (true) {
                System.out.println("Wain for client connection...");
                socket = serverSocket.accept();
                
                // Generate new Thread when client has connected
                ReceiveThread receiveThread = new ReceiveThread(socket);
                receiveThread.start();
                
                // Check the number of clients
                if (ReceiveThread.getClientCount() == 2) {
                   // Scene1 : Print banner when game has started
                    ReceiveThread.sendAll("");
                    String Scene1 = "⠨⠠⠡⠨⠠⠡⠨⠠⠡⠨⠠⠡⠨⠠⠡⠨⠠⠡⠨⠠⠡⠨⠠⠡⠨⡠⠡⠨⠠⠡⠨⠠⠡⠨⠠⠡⠨⠠⠡⠨⠠⠡⠨⠠⠡⠨⠠⠡⠨⠨\r\n"
                            + "⠌⠄⠅⠌⢸⣮⠠⠡⢨⣤⣥⣬⢸⡇⡈⠶⠷⣮⠂⣿⠀⠅⠌⠄⣵⣷⠨⠠⠡⠨⣠⣱⣳⣳⣨⡠⠁⣷⠳⠳⠳⠃⢌⣤⣥⣬⠨⣾⠀⠅\r\n"
                            + "⠅⠌⠰⠷⠫⣜⠻⢖⢐⢀⣲⡇⢸⣧⡆⣿⣛⣛⡀⣿⠋⠲⣷⣷⣿⣿⣷⣷⠮⢐⢨⢾⡚⣺⢮⠠⣥⣻⣻⣻⣻⣣⢂⢐⣰⡇⠌⣿⠀⠅\r\n"
                            + "⠅⠡⢙⣛⢛⠛⡛⡙⢢⣖⠏⡐⢸⡇⠄⢭⣭⣭⣥⣟⠨⢐⠈⣿⢽⡿⣯⡃⠅⡂⢶⠽⠽⠽⠵⢆⠢⡶⡶⡶⣶⡂⢢⣖⠏⠄⠅⣿⠀⠅\r\n"
                            + "⠅⠅⡂⠿⠶⠶⠶⠆⠨⢐⠐⡐⢸⠇⠨⢐⢀⠂⠄⡿⠨⢐⢰⡹⢙⠘⢗⠇⠅⡂⠸⠷⠞⠶⡳⢐⠀⡿⡭⡭⡭⡆⠨⢐⠨⠠⠡⢿⠀⠅\r\n"
                            + "⠁⠅⡂⠅⠌⠄⠅⠡⢁⠂⡂⢂⠂⠌⠨⢐⢐⠨⢐⠠⢁⢂⢐⠐⡐⠨⢐⠨⢐⠠⠁⠅⠡⢁⠂⡂⢂⢂⢐⢀⢂⠂⠅⡂⠌⠄⠅⡂⠌⡐\r";
                    ReceiveThread.sendAll(Scene1);
                    ReceiveThread.sendAll("타입을 선택해주세요.");
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (serverSocket != null) {
                try {
                    serverSocket.close();
                    System.out.println("Server closed.");
                } catch (IOException e) {
                    e.printStackTrace();
                    System.out.println("Server socket connection error.");
                }
            }
        }
    }
}

class ReceiveThread extends Thread {

    static List<PrintWriter> list = Collections.synchronizedList(new ArrayList<PrintWriter>());
    static int clientCount = 0;
    int client_num = 0;
    static int c=  0;
    static String[] name_list = new String[2];
    static int turn_num = 0;    
    static String[] inputMsg_list = new String[2];
    static Pokemon[] poke_list = new Pokemon[2];
    Socket socket = null;
    BufferedReader in = null;
    PrintWriter out = null;
	static GameManager gameManager;
	String battle_scene = 
			  "⠀                            ⡠⢠⠔⢀⡀⠀⠀⠀⠀⠀\n"
			+ "⠀⠀                       ⠀⠀ ⡔⢀⢂⢂⡈⡑⠀⠀⠀⠀\n"
			+ "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠐⡌⠵⠌⠔⠠⠅⠀⠀⠀⠀\n"
			+ "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠌⠣⠌⠔⣩⠀⠀⠀⠀⠀\n"
			+ "⠀⠀⠀⠀⠀⢀⢀⡀⢤⢀⡀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n"
			+ "⠀⠀⠀⠀⠀⠒⡈⠢⠂⠀⠰⠌⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n"
			+ "⠀⠀⠀⠀⠀⠚⢈⠆⢉⠎⡈⢰⠆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n"
			+ "⠀⠀⠀⠀⠀⠑⣒⡢⠀⠂⠤⠌⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n"
			+ "⠀⠀⠀⠀⠀⠙⠢⠳⠶⠮⠤⠙⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀"
			+ "";
    static String behavior_table="1. 손가락 흔들기 2. 상처약 사용하기 3. 스텟 보기 4. 항복하기 >>";
    static String line = "----------------------------------------------------";
   
    public ReceiveThread(Socket socket) {
        this.socket = socket;
        try {
            out = new PrintWriter(socket.getOutputStream());
            out.flush();
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            list.add(out);
            client_num = clientCount;
            inputMsg_list[client_num] = "";
            incrementClientCount();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static synchronized void incrementClientCount() {
        clientCount++;
    }
    public static synchronized void decrementClientCount() {
        clientCount--;
    }
    public static synchronized int getClientCount() {
        return clientCount;
    }
    public static void sendAll(String s) {
        synchronized (list) {
            for (PrintWriter out : list) {
                out.println(s);
                out.flush();
            }
        }
    }
    @Override
    public void run() {
        String name = "";
        try {
            // Recieve the name of client at first once
        	c = 0;
            inputMsg_list[0] = "";
            inputMsg_list[1] = "";
            turn_num = 0;
            name = in.readLine();
            name_list[clientCount-1] = name;            
            System.out.println(name + " has connected.");
            while (in != null) {
               String inputMsg = in.readLine();
               // c: the number of inputs of its clients
               c = c+1;
               // when client has sent the input, put the index of input of client that sent the input into inputMsg_list
               inputMsg_list[client_num] = inputMsg; 
                if(c == 2) {
                	System.out.println(name_list[0] + " " + name_list[1]);
                // after the client has input to server
                	if(turn_num == 0)  { 
                      FileOutputStream fos = new FileOutputStream("./userlist.txt");
                      fos.close();
                      System.out.println(inputMsg_list[0] +" "+ inputMsg_list[1]);
                      // Scene 2: print the state of each pokemon on each cpnsole of client
                      ReceiveThread.sendAll("");
                      boolean isSet = false;
                      for(String type: Pokemon.typeList) {
                    	  if(inputMsg_list[0].replace(name_list[0]+"/", "").equals(type)) {
                              poke_list[0] = new Pokemon(name_list[0], inputMsg_list[0].replace(name_list[0]+"/", ""));
                              isSet = true;
                              break;
                    	  }
                      }
                      if(!isSet) 
                          poke_list[0] = new Pokemon(name_list[0], "노말");
                      // to generate random object that has different seed
                      try {
							Thread.sleep(10);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
                      isSet = false;
                      for(String type: Pokemon.typeList) {
                    	  if(inputMsg_list[1].replace(name_list[1]+"/", "").equals(type)) {
                              poke_list[1] = new Pokemon(name_list[1], inputMsg_list[1].replace(name_list[1]+"/", ""));
                              isSet = true;
                              break;
                    	  }
                      }
                      if(!isSet) 
                      poke_list[1] = new Pokemon(name_list[1], "노말");
                      poke_list[0].setEnemy(poke_list[1]);
                      poke_list[1].setEnemy(poke_list[0]);
                      gameManager = new GameManager();
                  	  gameManager.setPokemon(poke_list[0], poke_list[1]);

                      // invalidinputError => normal type으로 처리
                      String stat1 = poke_list[0].ShowState();
                      String stat2 = poke_list[1].ShowState();
                      list.get(0).println(stat1);
                      list.get(0).flush();
                      list.get(1).println(stat2);
                      list.get(1).flush();
                      try {
							Thread.sleep(3000);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
                      
                      // 처음 맞딱뜨린 문구 띄우기
                      list.get(0).println(name_list[1]+"이(가) 승부를 걸어왔다!");
                      list.get(0).flush();
                      list.get(1).println(name_list[0]+"이(가) 승부를 걸어왔다!");
                      list.get(1).flush();
                      try {
							Thread.sleep(500);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
                      list.get(0).println(name_list[1]+"은(는) 토게피를 내보냈다!");
                      list.get(0).flush();
                      list.get(1).println(name_list[0]+"은(는) 토게피를 내보냈다!");
                      list.get(1).flush();
                      turn_num++;
                   }
                	else {
                		// Turn Calculation
                			                		
                		// move the pokemon one by one
                		if(inputMsg_list[0].substring(0, inputMsg_list[0].length()-2) != name_list[0]) {
                			// first input = first user
                			System.out.println("OK");
                			if(inputMsg_list[0].replace(name_list[0]+"/", "").equals("4")) {	
                    			// first user surrender or knocked
                				sendAll(name_list[0]+"이 항복했습니다.");
                				list.get(1).println("승리!");
                				list.get(1).flush();
                				list.get(0).println("패배");
                				list.get(0).flush();
                				sendAll("게임 종료.");
                				break;
                			}
                			else if(inputMsg_list[1].replace(name_list[1]+"/", "").equals("4")) {	
                			// second user surrender or knocked
                				sendAll(name_list[1]+"이 항복했습니다.");
                				list.get(0).println("승리!");
                				list.get(0).flush();
                				list.get(1).println("패배");
                				list.get(1).flush();
                				sendAll("게임 종료.");
                				break;
                			}
                			else gameManager.FirstMove(inputMsg_list[0].substring(inputMsg_list[0].length()-1), inputMsg_list[1].substring(inputMsg_list[1].length()-1));
            			}
                		else {
                			System.out.println("OK");
                			// first input = second user
                			if(inputMsg_list[1].replace(name_list[0]+"/", "").equals("4")) {	
                    			// first user surrender or knocked
                				sendAll(name_list[0]+"이 항복했습니다.");
                				list.get(1).println("승리!");
                				list.get(1).flush();
                				list.get(0).println("패배");
                				list.get(0).flush();
                				sendAll("게임 종료.");
                				break;
                			}
                			else if(inputMsg_list[1].replace(name_list[0]+"/", "").equals("4")) {	
                			// second user surrender or knocked
                				sendAll(name_list[1]+"이 항복했습니다.");
                				list.get(0).println("승리!");
                				list.get(0).flush();
                				list.get(1).println("패배");
                				list.get(1).flush();
                				sendAll("게임 종료.");
                				break;
                			}
                			else gameManager.FirstMove(inputMsg_list[1].substring(inputMsg_list[1].length()-1), inputMsg_list[0].substring(inputMsg_list[0].length()-1));
                		}
                		sendAll(line);
                		for(String output : gameManager.output1.split("\n")) {
                			sendAll(output);
                			try {
								Thread.sleep(500);
							} catch (InterruptedException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
                		}
                        sendAll(line);
                		list.get(0).println(gameManager.middleScene2);
                        list.get(0).flush();
                        list.get(1).println(gameManager.middleScene1);
                    	list.get(1).flush();
                    	sendAll(line);
                    	try {
							Thread.sleep(1000);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
                        for(String output : gameManager.output2.split("\n")) {
                			sendAll(output);
                			try {
								Thread.sleep(500);
							} catch (InterruptedException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
                		}
                        if(poke_list[0].HP == 0) {
                      	   sendAll(name_list[0]+"의 토게피는 쓰러졌다!");
      	       				list.get(1).println("승리!");
      	       				list.get(1).flush();
      	       				list.get(0).println("패배");
      	       				list.get(0).flush();
      	       				sendAll("게임 종료.");
      	       				break;
                         }
                         else if(poke_list[1].HP == 0) {
                      	   sendAll(name_list[1]+"의 토게피는 쓰러졌다!");
      	       				list.get(0).println("승리!");
      	       				list.get(0).flush();
      	       				list.get(1).println("패배");
      	       				list.get(1).flush();
      	       				sendAll("게임 종료.");
      	       				break;
                         }
                	}
                   // 턴 반복
                   // 배틀씬  보여주기
                    sendAll(line);
                    try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
                	list.get(0).println(poke_list[1].roughStateRight());
                    list.get(0).flush();
                	list.get(1).println(poke_list[0].roughStateRight());
                	list.get(1).flush();
                   sendAll(battle_scene);
                   list.get(0).println(poke_list[0].roughStateLeft());
                   list.get(0).flush();
               	   list.get(1).println(poke_list[1].roughStateLeft());
               	   list.get(1).flush();
                   sendAll(line);
                   
                   if(poke_list[0].HP == 0) {
                	   sendAll(name_list[0]+"의 토게피는 쓰러졌다!");
	       				list.get(1).println("승리!");
	       				list.get(1).flush();
	       				list.get(0).println("패배");
	       				list.get(0).flush();
	       				sendAll("게임 종료.");
	       				break;
                   }
                   else if(poke_list[1].HP == 0) {
                	   sendAll(name_list[1]+"의 토게피는 쓰러졌다!");
	       				list.get(0).println("승리!");
	       				list.get(0).flush();
	       				list.get(1).println("패배");
	       				list.get(1).flush();
	       				sendAll("게임 종료.");
	       				break;
                   }
                   
                   //sendAll(line);
                   // 할 수 있는 행동 보여주기
                   String behavior1 = name_list[0]+"의 토게피는 무엇을 할까?";
                   String behavior2 = name_list[1]+"의 토게피는 무엇을 할까?";
                   list.get(0).println(behavior1);
                   list.get(0).flush();
                   list.get(1).println(behavior2);
                   list.get(1).flush();
                   //할 수 있는 행동 테이블 보여주기
                   list.get(0).println(behavior_table);
                   list.get(0).flush();
                   list.get(1).println(behavior_table);
                   list.get(1).flush();
                   // 입력 초기화 및 턴 
                   c = 0;
                   inputMsg_list[0] = "";
                   inputMsg_list[1] = "";
                   
                   list.get(0).println(poke_list[0].ShowState());
                   list.get(0).flush();
                   list.get(1).println(poke_list[1].ShowState());
                   list.get(1).flush();
                }
                else {
                   // find the client that has input
                   int c_n = 0;
                   if(inputMsg_list[0].equals("")==true) {
                      c_n = 1;
                   }
                   list.get(c_n).println("상대방 입력 대기 중...");
                   list.get(c_n).flush();
                }
            }
            
            
        } catch (IOException e) {
            System.out.println(name + " connection error.");
        } finally {
            sendAll(name + " has disconnected.");
            list.remove(out);
            decrementClientCount();
            try {
                socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        System.out.println(name + " has disconnected.");
    }
}

