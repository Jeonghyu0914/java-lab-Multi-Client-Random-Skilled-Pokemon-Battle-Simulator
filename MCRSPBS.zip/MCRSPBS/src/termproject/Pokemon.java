package termproject;

import java.util.Arrays;
import java.util.Random;

public class Pokemon{
      public String name;
      public int MaxHP = 200;
      public int HP = MaxHP;
      public int originAD = 100;
      public int AD = originAD;
      public int originAP = 100;
      public int AP = originAP;
      public int originDF = 50;
      public int DF = originDF;
      public int originMR = 50;
      public int MR = originMR;
      public int originSP = 100;
      public int SP = originSP;
      public int ADcounter = 0;
      public int APcounter = 0;
      public int DFcounter = 0;
      public int MRcounter = 0;
      public int SPcounter = 0;

      public String type1;
      public String type2;
      public int condition = 0;
      public boolean isBarriered = false;
      
      public int potionCounter = 3;
      private Skill[] skillList = {
                  new AttackSkill("몸통박치기", 40, "노말", "!bump!", true, 100),
                  new AttackSkill("화염방사", 80, "불꽃", "<<<<<<<<<<<<<<<<<<<<<<<<<<!!\n<<<<<<<<<<<<<<<<<<<<<<<<<<!!", false, 90),
                  new AttackSkill("하이드로펌프", 100, "물", "~~~~~~~~~~~~~~~~~~~~~~~~~~>>\n~~~~~~~~~~~~~~~~~~~~~~~~~~>>", false, 85),
                  new AttackSkill("잎날가르기", 40, "풀", ")     )     )     )    )    )", true, 95),
                  new AttackSkill("100만볼트", 90, "전기", "ㅆㅆㅆㅆㅆㅆㅆㅆㅆㅆㅆㅆㅆㅆㅆㅆㅆㅆㅆㅆ\nㅆㅆㅆㅆㅆㅆㅆㅆㅆㅆㅆㅆㅆㅆㅆㅆㅆㅆㅆㅆ", false, 95),
                  new AttackSkill("냉동빔", 90, "얼음", "****************************\n****************************", false, 100),
                  new AttackSkill("무릎차기", 150, "격투", "                   !! >>>\n                      !! >>>", true, 50),
                  new AttackSkill("오물폭탄", 80, "독", "~~~~@~~^~&~*~~(~(~~~(&~^~\n~~~!@#&~~#!@(~~!@~!@~$~$~~))", false, 100),
                  new AttackSkill("지진", 100, "땅", "___________!!!!!!___________\n___________________________", true, 100),
                  new AttackSkill("폭풍", 125, "비행", "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n@@@@@@@@@@@@@@@@@@@@@@@@@@@", true, 75),
                  new AttackSkill("사이코키네시스", 100, "에스퍼", "$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n$$$$$$$$$$$$$$$$$$$$$$$$$$", false, 100),
                  new AttackSkill("시저크로스", 90, "벌레", "XXXXXXXXXXXXXXXXXXXX\nXXXXXXXXXXXXXXXXXXXX", true, 100),
                  new AttackSkill("스톤엣지", 80, "바위", "^^^^^^^^^^^^^^\n^^^^^^^^^^^^^^", true, 90),
                  new AttackSkill("섀도볼", 80, "고스트", "~~~~~~~~~~~~~~~~~@", false, 100),
                  new AttackSkill("용성군", 150, "드래곤", "\\\\\\.....!@*#*\n \\\\\\.....!@*#*)(!!@#!\n  \\\\\\.....!@*#*)(!!@#!!@#!@$", true, 90),
                  new AttackSkill("악의파동", 80, "악", "~~~~~~~~~~~~~~~~~~ -_-\n~~~~~~~~~~~~~~~~~~ -_-", false, 90),
                  new AttackSkill("철제광선", 120, "강철", "----------------------\n----------------------\n----------------------", false, 100),
                  new AttackSkill("문포스", 90, "페어리", "        @ \n       @@@\n        @", false, 100),
                  new ConditionalSkill("도깨비불", "                     !!",  1, 100),
                  new ConditionalSkill("독가루", "                     @@", 2, 60),
                  new ConditionalSkill("맹독", "                     @@@@", 3, 100),   
                  new ConditionalSkill("전기자석파", "                       xxxx", 4, 90),
                  new ConditionalSkill("다크홀", "                     zz,,,", 5, 75),
                  new ConditionalSkill("아로마테라피", "                     ^^", 0, 100),
                  new Barrier()
               };
      public int condTurn;
      public Pokemon enemy;
      private Random random = new Random();
      // public Skill[] skillList;
      public static String[] typeList = new String[]
            {"노말", "불꽃", "물", "풀", "전기", "얼음", "격투",
                  "독", "땅", "비행", "에스퍼", "벌레", "바위", "고스트",
                  "드래곤", "악", "강철", "페어리"};
      Pokemon(String name, String type1){
         this.name = name; //Identify Pokemon
         this.type1 = type1; //Chosen type by user
         // randomly decided the second type of pokemon
         this.type2 = Pokemon.typeList[random.nextInt(17)];
         random.setSeed(System.currentTimeMillis());
      }
      public void setEnemy(Pokemon p) {
         this.enemy = p;
      }
      
      public String move(String input){
         String output = "";
         if(enemy.HP == 0) return "";
         switch(input) {
         case "1":
            if(this.condition == 4) {
                if(random.nextInt(3) == 0) {
                   return output + this.name + "의 토게피는 몸이 져려 기술을 사용할 수 없다!";
                }
             }
            if(this.condition == 5) return output + this.name + "의 토게피는 쿨쿨 자고 있다!";
            if(this.condition == 6) return output + this.name + "의 토게피는 몸이 얼어 움직일 수 없다!";
            output += (this.name +"의 토게피의 손가락흔들기!\n");
            int randomSkillidx = random.nextInt(skillList.length);
            output += this.name+"의 토게피는 "+skillList[randomSkillidx].getName()+"을(를) 사용했다!\n";
            output += (skillList[randomSkillidx].getSymbol() + "\n");
            if(random.nextInt(100) >= skillList[randomSkillidx].getHitRate()) {
               return output + enemy.name + "의 토게피에게는 맞지 않았다!";
            }
            switch(skillList[randomSkillidx].getTag()) {
            case 0:
               AttackSkill as = (AttackSkill) skillList[randomSkillidx];
               float damage = (float)(as.getDamage());
               String type = as.getType();
               float weight = typeWeightCal(type, enemy.type1) * typeWeightCal(type, enemy.type2);
               switch((int)(weight * 4)) {
               case 0: 
                  output += (enemy.name + "의 토게피에게는 효과가 없었다.\n");
                  break;
               case 1:
                  output += "효과가 매우 별로인 듯 하다...\n";
                  break;
               case 2:
                  output += "효과가 별로인 듯 하다...\n";
                  break;
               case 8:
                  output += "효과가 굉장했다!\n";
                  break;
               case 16:
                  output += "효과가 매우 굉장했다!\n";
                  break;
               }
               if(as.isAD) damage = (float)(this.AD * damage * weight * ((type1 == type || type2 == type)? 1.5: 1) / (enemy.MaxHP * enemy.DF / 0.411 * (this.condition == 1? 2 : 1))); // * 특성 * 도구
               else damage = (float)(this.AP * damage * weight * ((type1 == type || type2 == type)? 1.5: 1) / (enemy.MaxHP * enemy.MR / 0.411));
               damage *= 100;
               if(enemy.isBarriered) {
                  enemy.isBarriered = false;
                   return output + enemy.name + "의 토게피는 공격으로부터 몸을 지켰다!\n";
               }
               enemy.HP -= (int)damage;
               // 수정
               
               
               if(damage != 0) {
                  if(enemy.HP <= 0) {
                     int previous_hp = enemy.HP+(int)damage;
                     output += (enemy.name + "의 토게피는 " + previous_hp + "만큼의 피해를 입었다!\n");
                     enemy.HP =0;
                  }
                  else {
                     output += (enemy.name + "의 토게피는 " + (int)damage + "만큼의 피해를 입었다!\n");
                  }
                  
               }
             //수정 끝
               output += as.additive(this);
               return output;
            case 1:
               // Conditional Skill has used
               ConditionalSkill cs = (ConditionalSkill)skillList[randomSkillidx];
               if(cs.condition == 0) {
                  if(this.condition == 0) output += (this.name + "의 토게피에겐 효과가 없는 듯 하다...\n");
                  else {
                     if(this.condition == 4) this.SP *= 2;
                     cs.setCondition(this);
                     output += "토게피의 상태가 말끔히 해결되었다!\n";
                  }
                  return output;
               }
               if(enemy.isBarriered) {
                  enemy.isBarriered = false;
                   return output + enemy.name + "의 토게피는 공격으로부터 몸을 지켰다!\n";
               }
               if(enemy.condition != 0) {
                  return output + enemy.name + "의 토게피에겐 효과가 없는 듯 하다...\n";
               }
               cs.setCondition(enemy);
               switch(cs.condition) {
               case 1:
                  return output + enemy.name + "의 토게피는 화상을 입었다!\n";
               case 2:
                  return output + enemy.name + "의 토게피는 독에 걸렸다!\n";
               case 3:
                  return output + enemy.name + "의 토게피는 맹독에 걸렸다!\n";
               case 4:
                  return output + enemy.name + "의 토게피는 마비 상태에 빠졌다!\n";
               case 5:
                  return output + enemy.name + "의 토게피는 잠들어버렸다!\n";
               }
            case 2:
              this.isBarriered = true;
              output += (this.name + "의 토게피는 방에 태세에 들어갔다!\n");
               return output;
            }
            break;
         case "2":
            int exceedHP;
            output += (this.name + "은(는) 상처약을 썼다!\n");
            if(this.potionCounter == 0) return output + "남아있는 상처약이 없다!\n";
            this.potionCounter -= 1;
            if(this.HP == MaxHP) return output + "토게피의 체력은 이미 가득 차있다.\n";
            this.HP += 50;
            exceedHP = this.HP - MaxHP;
            if(exceedHP > 0) {
              this.HP = MaxHP;
              output += "토게피의 체력이 " + (50 - exceedHP) + "만큼 회복되었다.\n";
            }
            else {
               output += "토게피의 체력이 50만큼 회복되었다.\n";
            }
         }
         return output;
      }
      
      public String ShowState() {
         String state = "";
         state = state + "이름: "+this.name+"의 토게피\n";
         state = state + "타입: "+this.type1+" / "+this.type2+"\n";
         state = state +"상태: ";
         switch(condition) {
         case 0: state = state +"정상"; break;
         case 1: state = state +"화상"; break;
         case 2: state = state +"독"; break;
         case 3: state = state +"맹독"; break;
         case 4: state = state +"마비"; break;
         case 5: state = state +"잠듦"; break;
         case 6: state = state +"얼음"; break;
         }
         state = state+"\n";
         state = state + "체력: "+this.HP+"\n";
         state = state +"공격력: "+this.AD+"\n";
         state = state +"방어: "+this.DF+"\n";
         state = state +"특수공격력: "+this.AP+"\n";
         state = state +"특수방어력: "+this.MR+"\n";
         state = state +"스피드: "+this.SP+"\n";
         return state;
      }
      public String roughStateLeft() {
        String output = "";
         output += "      "+this.name+"의 토게피";
         switch(this.condition) {
         case 1:
            output += " [화상]\n";
            break;
         case 2:
         case 3:     
            output += " [독]\n";
            break;
         case 4:
            output += " [마비]\n";
            break;
         case 5:
            output += " [잠듦]\n";
            break;
         case 6:
            output += " [얼음]\n";
            break;
         default:
            output += "\n";
         }
         output += "      HP: "+this.HP;
         return output;
      }
      public String roughStateRight() {
         String output = "";
         output += "                            "+this.name+"의 토게피";
         switch(this.condition) {
            case 1:
               output += " [화상]\n";
               break;
            case 2:
            case 3:     
               output += " [독]\n";
               break;
            case 4:
               output += " [마비]\n";
               break;
            case 5:
               output += " [잠듦]\n";
               break;
            case 6:
               output += " [얼음]\n";
               break;
            default:
               output += "\n";
            }
         output += "                            HP: "+this.HP;
         return output;
      }
      public float typeWeightCal(String skillType, String pokemonType) {
         float[][] typeChart = {{1,1,1,1,1,1,1,1,1,1,1,1,(float) 0.5,0,1,1,(float) 0.5,1},
                           {1,(float) 0.5,(float) 0.5,2,1,2,1,1,1,1,1,2,(float) 0.5,1,(float) 0.5,1,2,1},
                           {1,2,(float) 0.5,(float) 0.5,1,1,1,1,2,1,1,1,2,1,(float) 0.5,1,1,1},
                           {1,(float) 0.5,2,(float) 0.5,1,1,1,(float) 0.5,2,(float) 0.5,1,(float) 0.5,2,1,(float) 0.5,1,(float) 0.5,1},
                           {1,1,2,(float) 0.5,(float) 0.5,1,1,1,0,2,1,1,1,1,(float) 0.5,1,1,1},
                           {1,(float) 0.5,(float) 0.5,2,1,(float) 0.5,1,1,2,2,1,1,1,1,2,1,(float) 0.5,1},
                           {2,1,1,1,1,2,1,(float) 0.5,1,(float) 0.5,(float) 0.5,(float) 0.5,2,0,1,2,2,(float) 0.5},
                           {1,1,1,2,1,1,1,(float) 0.5,(float) 0.5,1,1,1,(float) 0.5,(float) 0.5,1,1,0,2},
                           {1,2,1,(float) 0.5,2,1,1,2,1,0,1,(float) 0.5,2,1,1,1,2,1},
                           {1,1,1,2,(float) 0.5,1,2,1,1,1,1,2,(float) 0.5,1,1,1,(float) 0.5,1},
                           {1,1,1,1,1,1,2,2,1,1,(float) 0.5,1,1,1,1,0,(float) 0.5,1},
                           {1,(float) 0.5,1,2,1,1,(float) 0.5,(float) 0.5,1,(float) 0.5,2,1,1,(float) 0.5,1,2,(float) 0.5,(float) 0.5},
                           {1,2,1,1,1,2,(float) 0.5,1,(float) 0.5,2,1,2,1,1,1,1,(float) 0.5,1},
                           {0,1,1,1,1,1,1,1,1,1,2,1,1,2,1,(float) 0.5,1,1},
                           {1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,1,(float) 0.5,0},
                           {1,1,1,1,1,1,(float) 0.5,1,1,1,2,1,1,2,1,(float) 0.5,1,(float) 0.5},
                           {1,(float) 0.5,(float) 0.5,1,(float) 0.5,2,1,1,1,1,1,1,2,1,1,1,(float) 0.5,2},
                           {1,(float) 0.5,1,1,1,1,2,(float) 0.5,1,1,1,1,1,1,2,2,(float) 0.5,1}};
         return typeChart[Arrays.asList(this.typeList).indexOf(skillType)][Arrays.asList(this.typeList).indexOf(pokemonType)];
      }
   }
