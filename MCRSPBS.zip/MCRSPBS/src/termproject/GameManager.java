package termproject;

import java.util.Random;

public class GameManager{
	public Pokemon pokemon1;
	public Pokemon pokemon2;
	public String output1 = "";
	public String output2 = "";
	public String middleScene1 = "";
	public String middleScene2 = "";
	String battle_scene = 
			  "⠀                            ⡠⢠⠔⢀⡀⠀⠀⠀⠀⠀\n"
			+ "⠀⠀                       ⠀⠀ ⡔⢀⢂⢂⡈⡑⠀⠀⠀⠀\n"
			+ "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠐⡌⠵⠌⠔⠠⠅⠀⠀⠀⠀\n"
			+ "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠌⠣⠌⠔⣩⠀⠀⠀⠀⠀\n"
			+ "⠀⠀⠀⠀⠀⢀⢀⡀⢤⢀⡀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n"
			+ "⠀⠀⠀⠀⠀⠒⡈⠢⠂⠀⠰⠌⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n"
			+ "⠀⠀⠀⠀⠀⠚⢈⠆⢉⠎⡈⢰⠆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n"
			+ "⠀⠀⠀⠀⠀⠑⣒⡢⠀⠂⠤⠌⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n"
			+ "⠀⠀⠀⠀⠀⠙⠢⠳⠶⠮⠤⠙⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀"
			+ "";
	public int turn = 0;
	public void setPokemon(Pokemon pokemon1, Pokemon pokemon2){
		this.pokemon1 = pokemon1;
		this.pokemon2 = pokemon2;
		
	}
	public void FirstMove(String input1, String input2) { // int input (arg)
		if(!input1.equals("1") && !input1.equals("2")) input1 = "1";
		if(!input2.equals("1") && !input2.equals("2")) input2 = "1";
		System.out.println(input1 + input2);
		output1 = "";
		output2 = "";
		middleScene1 = "";
		middleScene2 = "";
		if(input1.equals("2") || pokemon1.SP > pokemon2.SP ) {

				output1 += conditionCheck(pokemon1);
				if(pokemon1.HP != 0) output1 += pokemon1.move(input1);
				middleScene1 = pokemon1.roughStateRight() + "\n" + battle_scene + "\n" + pokemon2.roughStateLeft();
				middleScene2 = pokemon2.roughStateRight() + "\n" + battle_scene + "\n" + pokemon1.roughStateLeft();
				if(pokemon2.HP == 0 || pokemon1.HP == 0) return;				
				output2 += conditionCheck(pokemon2);
				output2 += pokemon2.move(input2);
		}
		else if(input2.equals("2") || pokemon1.SP < pokemon2.SP) {
			
				output1 += conditionCheck(pokemon2);
				if(pokemon2.HP != 0) output1 += pokemon2.move(input2);
				middleScene1 = pokemon1.roughStateRight() + "\n" + battle_scene + "\n" + pokemon2.roughStateLeft(); // for pokemon1
				middleScene2 = pokemon2.roughStateRight() + "\n" + battle_scene + "\n" +pokemon1.roughStateLeft(); // for pokemon2
				if(pokemon2.HP == 0 || pokemon1.HP == 0) return;
				output2 += conditionCheck(pokemon1);
				output2 += pokemon1.move(input1);
		}
		else {
			Random random = new Random();
			if(random.nextInt(2) == 0) {
				output1 += conditionCheck(pokemon1);
				if(pokemon1.HP != 0) output1 += pokemon1.move(input1);
				middleScene1 = pokemon1.roughStateRight() + "\n" + battle_scene + "\n" + pokemon2.roughStateLeft();
				middleScene2 = pokemon2.roughStateRight() + "\n" + battle_scene + "\n" + pokemon1.roughStateLeft();
				if(pokemon2.HP == 0 || pokemon1.HP == 0) return;				
				output2 += conditionCheck(pokemon2);
				output2 += pokemon2.move(input2);

			}
			else {
				output1 += conditionCheck(pokemon2);
				if(pokemon2.HP != 0) output1 += pokemon2.move(input2);
				middleScene1 = pokemon1.roughStateRight() + "\n" + battle_scene + "\n" + pokemon2.roughStateLeft(); // for pokemon1
				middleScene2 = pokemon2.roughStateRight() + "\n" + battle_scene + "\n" +pokemon1.roughStateLeft(); // for pokemon2
				if(pokemon2.HP == 0 || pokemon1.HP == 0) return;				
				output2 += conditionCheck(pokemon1);
				output2 += pokemon1.move(input1);
			}
		}
		turn++;
	}
	public String conditionCheck(Pokemon p) {
		String output = "";
		Random random = new Random();
		random.setSeed(System.currentTimeMillis());
		if(p.condition == 0) return output;
		p.condTurn++;
		switch(p.condition) {
		case 1: 
			// burned
			p.HP -= (int)(p.MaxHP / 16);
			if(p.HP <= 0) p.HP = 0;
			return output + p.name + "의 토게피는 화상 데미지를 입고 있다!\n";
		case 2:
			// addicted
			p.HP -= (int)(p.MaxHP / 16);
			if(p.HP <= 0) p.HP = 0;
			return output + p.name + "의 토게피는 독 데미지를 입고 있다!\n";
		case 3:
			// super addicted
			p.HP -= (int)((p.MaxHP / 32) * p.condTurn);
			if(p.HP <= 0) p.HP = 0;
			return output + p.name + "의 토게피는 독 데미지를 입고 있다!\n";	
		case 4:
			// paralyzed
			if(random.nextInt(100) < 30 * (p.condTurn-1)) {
				p.condition = 0;
				p.condTurn = 0;
				p.SP *= 2;
				return output + "토게피의 몸저림이 풀렸다!\n";
			}
			if(p.condTurn == 1) p.SP /= 2;
			return output + p.name + "의 토게피는 마비에 걸려있다\n!";
		case 5:
			// sleep
			if(random.nextInt(100) < 30 * (p.condTurn-1)) {
				p.condition = 0;
				p.condTurn = 0;
				return output + p.name + "의 토게피는 눈을 떴다!\n";
			}
			break;
		case 6:
			// iced
			if(random.nextInt(100) < 30 * (p.condTurn-1)) {
				p.condition = 0;
				p.condTurn = 0;
				return output + "토게피의 몸이 녹았다!\n";
			}
			break;
		}
		return output;
		
	}
}